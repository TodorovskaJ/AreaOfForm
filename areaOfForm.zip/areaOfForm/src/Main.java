import java.util.Scanner;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please choose an option, for which form to calculate area: ");
        System.out.println("1.Square");
        System.out.println("2.Rectangle ");
        System.out.println("3.Circle");

        int n = scanner.nextInt();
        while (true) {
            if (n == 1) {
                System.out.println("AREA OF SQUARE");
                System.out.println("Please insert side of square in cm");
                double sideSquare = scanner.nextInt();
                Square square = new Square("Square", sideSquare);
                double result = square.CalculateArea();
                System.out.println("The area of square is: " + String.format("%.2f", result) + "cm\u00B2.");
                System.out.println("Do you want to calculate perimeter of square. Press yes or no?");
                Scanner scan = new Scanner(System.in);
                String answer = scan.nextLine();
                if (answer.equals("yes")) {
                    double perimeter = square.CalculatePerimeter();
                    System.out.println("Perimeter of square is: " + String.format("%.2f", perimeter) + "cm.");
                    break;
                } else {
                    break;
                }

            } else if (n == 2) {
                System.out.println("AREA OF RECTANGLE");
                System.out.println("Please insert width od rectangle in cm");
                double width = scanner.nextInt();
                System.out.println("Please insert height of rectangle in cm");
                double height = scanner.nextInt();
                Rectangle rectangle = new Rectangle("Rectangle", width, height);
                double result = rectangle.CalculateArea();
                System.out.println("The area of rectangle is: " + String.format("%.2f", result) + "cm\u00B2.");
                System.out.println("Do you want to calculate perimeter of rectangle. Press yes or no?");
                Scanner scan = new Scanner(System.in);
                String answer = scan.nextLine();
                if (answer.equals("yes")) {

                    double perimeter = rectangle.CalculatePerimeter();
                    System.out.println("Perimeter of rectangle is: " + String.format("%.2f", perimeter) + "cm.");
                    break;

                } else {
                    break;
                }


            } else if (n == 3) {
                System.out.println("AREA OF CIRCLE");
                System.out.println("Please insert radius of circle in cm");
                double radius = scanner.nextInt();
                Ciircle ciircle = new Ciircle("Circle", radius);
                double result = ciircle.CalculateArea();
                System.out.println("The area of circle is: " + String.format("%.2f", result) + "cm\u00B2.");
                System.out.println("Do you want to calculate perimeter of circle. Press yes or no?");
                Scanner scan = new Scanner(System.in);
                String answer = scan.nextLine();
                if (answer.equals("yes")) {
                    double perimeter = ciircle.CalculatePerimeter();
                    System.out.println("Perimeter of circle is: " + String.format("%.2f", perimeter) + "cm.");
                    break;
                } else {break;}
            } else {
                System.out.println("Invalid operation!");
            }


        }
    }
}