import interfaces.FormInterface;

public class Square  extends Form implements FormInterface {
    private double width;

    public Square (String name, double width){
        super(name);
        this.width = width;
    }

    public  void setWidth (double width){
        this.width = width;
    }

    public double getWidth () {
        return width;
    }

    public double CalculateArea () {
        return width * width;
    }

    @Override
    public double CalculatePerimeter() {
      return 4 * width;
    }

  /*  public  double CalculatePerimetar(){
        return 4*width;
    }*/


}
