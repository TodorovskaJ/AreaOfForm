import interfaces.FormInterface;

public class Ciircle extends Square implements FormInterface {

    public Ciircle (String name, double width){
        super(name,width);
    }


    public double CalculateArea(){
        return getWidth() * 3.14;
    }
    @Override
    public double CalculatePerimeter() {
        return    2 * 3.14* getWidth();

    }
}
