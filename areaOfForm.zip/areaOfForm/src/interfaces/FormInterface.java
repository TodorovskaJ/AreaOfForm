package interfaces;

public interface FormInterface {
    public double CalculatePerimeter();

}
