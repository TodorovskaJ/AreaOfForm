import interfaces.FormInterface;

public class Rectangle extends Square implements FormInterface {
    private double height;

    public Rectangle(String name, double width, double height) {
        super(name, width);
        this.height = height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public double getHeight() {
        return height;
    }

    public double CalculateArea (){
        double result = getWidth() * height;
        return result;
    }
    @Override
    public double CalculatePerimeter() {
        return  (2* height)+ (2 * getWidth());

    }
}
